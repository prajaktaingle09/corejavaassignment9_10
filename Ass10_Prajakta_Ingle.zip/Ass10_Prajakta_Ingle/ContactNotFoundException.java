
public class ContactNotFoundException extends Exception {
	public ContactNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}

	
}
